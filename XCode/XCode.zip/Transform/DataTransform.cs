﻿using System;
using System.Collections.Generic;
using System.Text;
using XCode.DataAccessLayer;

namespace XCode.Transform
{
    /// <summary>数据转换</summary>
    public class DataTransform : TransformBase<DataTransform>
    {
        #region 方法
        /// <summary>执行</summary>
        /// <returns></returns>
        public override Int32 Transform()
        {
            return 0;
        }
        #endregion
    }
}